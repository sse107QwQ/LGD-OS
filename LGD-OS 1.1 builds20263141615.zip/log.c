// log.c
#include "log.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdarg.h>
#include <sys/stat.h>
#include <ctype.h>

#ifdef _WIN32
    #include <windows.h>
    #include <direct.h>
    #define MKDIR(path) _mkdir(path)
    #define PATH_SEPARATOR '\\'
#else
    #include <unistd.h>
    #include <libgen.h>
    #define MKDIR(path) mkdir(path, 0755)
    #define PATH_SEPARATOR '/'
#endif

// ��̬��������
static void ensure_log_dir(const char *log_dir);
static void get_log_filename(Logger *logger, char *buffer, size_t size);
static void rotate_log_if_needed(Logger *logger);
static void close_current_logfile(Logger *logger);
static int open_logfile(Logger *logger, const char *filename);
static const char* level_to_string(LogLevel level);
static void cleanup_old_logs(Logger *logger, const char *current_file);

// ��־ϵͳ��ʼ��
Logger* log_init(const char *exe_path) {
    Logger *logger = (Logger*)malloc(sizeof(Logger));
    if (!logger) {
        return NULL;
    }

    // ����Ĭ������
    logger->config.enabled = 1;
    logger->config.level = LOG_LEVEL_INFO;
    logger->config.max_files = 30;  // ����30����־�ļ�
    logger->config.max_file_size = 10 * 1024 * 1024;  // 10MB
    logger->config.use_daily_files = 1;
    logger->current_log_file = NULL;
    logger->current_filename[0] = '\0';

    // ��ȡ��ִ���ļ�����Ŀ¼
    char exe_dir[1024] = {0};

    if (exe_path && exe_path[0] != '\0') {
        // �Ӳ�����ȡ
        strncpy(exe_dir, exe_path, sizeof(exe_dir) - 1);
    } else {
        // �����Զ���ȡ
#ifdef _WIN32
        GetModuleFileNameA(NULL, exe_dir, sizeof(exe_dir));
#else
        ssize_t count = readlink("/proc/self/exe", exe_dir, sizeof(exe_dir) - 1);
        if (count <= 0) {
            // ���÷���
            if (getcwd(exe_dir, sizeof(exe_dir)) == NULL) {
                strcpy(exe_dir, ".");
            }
        } else {
            exe_dir[count] = '\0';
        }
#endif
    }

    // ��ȡĿ¼����
    char *last_slash = strrchr(exe_dir, '/');
    if (!last_slash) {
        last_slash = strrchr(exe_dir, '\\');
    }

    if (last_slash) {
        *last_slash = '\0';  // ȥ���ļ�����ֻ����Ŀ¼
    }

    // ������־Ŀ¼·��
    snprintf(logger->config.log_dir, sizeof(logger->config.log_dir),
             "%s%clog", exe_dir, PATH_SEPARATOR);

    // ȷ����־Ŀ¼����
    ensure_log_dir(logger->config.log_dir);

    // ��ȡ��ǰ��־�ļ���
    char log_filename[1024];
    get_log_filename(logger, log_filename, sizeof(log_filename));

    // �����ɵ���־�ļ�
    cleanup_old_logs(logger, log_filename);

    // ����־�ļ�
    if (!open_logfile(logger, log_filename)) {
        free(logger);
        return NULL;
    }

    // д��������־
    LOG_INFO(logger, "=== LGD-OS Shell ��־ϵͳ���� ===");
    LOG_INFO(logger, "��־Ŀ¼: %s", logger->config.log_dir);
    LOG_INFO(logger, "��־����: %s", level_to_string(logger->config.level));

    return logger;
}

// ������־ϵͳ
void log_cleanup(Logger *logger) {
    if (!logger) return;

    if (logger->current_log_file) {
        LOG_INFO(logger, "=== LGD-OS Shell ��־ϵͳ�ر� ===");
        fclose(logger->current_log_file);
        logger->current_log_file = NULL;
    }

    free(logger);
}

// ȷ����־Ŀ¼����
static void ensure_log_dir(const char *log_dir) {
    struct stat st = {0};

    if (stat(log_dir, &st) == -1) {
        // ����Ŀ¼
        if (MKDIR(log_dir) != 0) {
            // �������ʧ�ܣ����Դ�����Ŀ¼
            char parent_dir[1024];
            strncpy(parent_dir, log_dir, sizeof(parent_dir) - 1);

            char *last_sep = strrchr(parent_dir, PATH_SEPARATOR);
            if (last_sep) {
                *last_sep = '\0';
                ensure_log_dir(parent_dir);
                MKDIR(log_dir);
            }
        }
    }
}

// ��ȡ��־�ļ���
static void get_log_filename(Logger *logger, char *buffer, size_t size) {
    time_t now = time(NULL);
    struct tm *tm_info = localtime(&now);

    if (logger->config.use_daily_files) {
        // �����ڷָ����־�ļ�
        snprintf(buffer, size, "%s%cshell_%04d%02d%02d.log",
                 logger->config.log_dir, PATH_SEPARATOR,
                 tm_info->tm_year + 1900,
                 tm_info->tm_mon + 1,
                 tm_info->tm_mday);
    } else {
        // ������־�ļ�
        snprintf(buffer, size, "%s%cshell.log",
                 logger->config.log_dir, PATH_SEPARATOR);
    }
}

// ��鲢��ת��־�ļ�
static void rotate_log_if_needed(Logger *logger) {
    if (!logger->current_log_file) return;

    // ����ļ���С
    fseek(logger->current_log_file, 0, SEEK_END);
    long file_size = ftell(logger->current_log_file);
    fseek(logger->current_log_file, 0, SEEK_SET);

    if (file_size > logger->config.max_file_size) {
        // �ļ�̫����Ҫ��ת
        close_current_logfile(logger);

        // ��������ǰ�ļ�
        time_t now = time(NULL);
        struct tm *tm_info = localtime(&now);
        char backup_name[1024];

        snprintf(backup_name, sizeof(backup_name),
                "%s%cshell_%04d%02d%02d_%02d%02d%02d_backup.log",
                logger->config.log_dir, PATH_SEPARATOR,
                tm_info->tm_year + 1900,
                tm_info->tm_mon + 1,
                tm_info->tm_mday,
                tm_info->tm_hour,
                tm_info->tm_min,
                tm_info->tm_sec);

        rename(logger->current_filename, backup_name);

        // ���´���־�ļ�
        char new_filename[1024];
        get_log_filename(logger, new_filename, sizeof(new_filename));
        open_logfile(logger, new_filename);
    }
}

// �رյ�ǰ��־�ļ�
static void close_current_logfile(Logger *logger) {
    if (logger->current_log_file) {
        fclose(logger->current_log_file);
        logger->current_log_file = NULL;
    }
}

// ����־�ļ�
static int open_logfile(Logger *logger, const char *filename) {
    close_current_logfile(logger);

    logger->current_log_file = fopen(filename, "a");
    if (!logger->current_log_file) {
        return 0;
    }

    strncpy(logger->current_filename, filename, sizeof(logger->current_filename) - 1);
    return 1;
}

// ����־����ת��Ϊ�ַ���
static const char* level_to_string(LogLevel level) {
    switch (level) {
        case LOG_LEVEL_DEBUG:    return "DEBUG";
        case LOG_LEVEL_INFO:     return "INFO";
        case LOG_LEVEL_WARNING:  return "WARNING";
        case LOG_LEVEL_ERROR:    return "ERROR";
        case LOG_LEVEL_CRITICAL: return "CRITICAL";
        default:                 return "UNKNOWN";
    }
}

// �����ɵ���־�ļ�
static void cleanup_old_logs(Logger *logger, const char *current_file) {
    // �������������������־�ļ����߼�
    // ����ʱ���ϵ������ֻ�������
    // ʵ��ʵ�ֿ�����Ҫ����Ŀ¼��ɾ����ɵ��ļ�
}

// ��¼��Ϣ
void log_message(Logger *logger, LogLevel level, const char *function,
                 int line, const char *format, ...) {
    if (!logger || !logger->config.enabled || level < logger->config.level) {
        return;
    }

    // ����Ƿ���Ҫ��ת��־
    rotate_log_if_needed(logger);

    if (!logger->current_log_file) {
        // ���´���־�ļ�
        char filename[1024];
        get_log_filename(logger, filename, sizeof(filename));
        if (!open_logfile(logger, filename)) {
            return;
        }
    }

    // ��ȡ��ǰʱ��
    time_t now = time(NULL);
    struct tm *tm_info = localtime(&now);

    // д��ʱ�������־����
    fprintf(logger->current_log_file,
            "[%04d-%02d-%02d %02d:%02d:%02d] [%-8s] ",
            tm_info->tm_year + 1900,
            tm_info->tm_mon + 1,
            tm_info->tm_mday,
            tm_info->tm_hour,
            tm_info->tm_min,
            tm_info->tm_sec,
            level_to_string(level));

    // д�뺯�������к�
    if (function && function[0] != '\0') {
        fprintf(logger->current_log_file, "[%s:%d] ", function, line);
    }

    // ������Ϣ
    va_list args;
    va_start(args, format);
    vfprintf(logger->current_log_file, format, args);
    va_end(args);

    fprintf(logger->current_log_file, "\n");
    fflush(logger->current_log_file);

    // ����Ǵ��󼶱�ͬʱ�ڿ���̨���
    if (level >= LOG_LEVEL_ERROR) {
        fprintf(stderr, "[%s] ", level_to_string(level));
        va_start(args, format);
        vfprintf(stderr, format, args);
        va_end(args);
        fprintf(stderr, "\n");
    }
}

// ��¼����
void log_command(Logger *logger, const char *command, const char *working_dir) {
    if (!logger || !command || command[0] == '\0') {
        return;
    }

    if (working_dir) {
        LOG_INFO(logger, "CMD [%s]: %s", working_dir, command);
    } else {
        LOG_INFO(logger, "CMD: %s", command);
    }
}
