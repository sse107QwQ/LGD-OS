// log.h
#ifndef LOG_H
#define LOG_H

#include <stdio.h>
#include <time.h>

// ��־����ö��
typedef enum {
    LOG_LEVEL_DEBUG = 0,
    LOG_LEVEL_INFO = 1,
    LOG_LEVEL_WARNING = 2,
    LOG_LEVEL_ERROR = 3,
    LOG_LEVEL_CRITICAL = 4
} LogLevel;

// ��־���ýṹ
typedef struct {
    int enabled;                // �Ƿ�������־
    LogLevel level;             // ��־����
    char log_dir[1024];         // ��־Ŀ¼·��
    int max_files;              // �����־�ļ���
    long max_file_size;         // ����ļ���С���ֽڣ�
    int use_daily_files;        // �Ƿ����ڷָ��ļ�
} LogConfig;

// ��־������
typedef struct {
    LogConfig config;
    FILE *current_log_file;
    char current_filename[1024];
} Logger;

// ��������
Logger* log_init(const char *exe_path);
void log_cleanup(Logger *logger);
void log_message(Logger *logger, LogLevel level, const char *function,
                 int line, const char *format, ...);
void log_command(Logger *logger, const char *command, const char *working_dir);

// ��ݵ���־��
#define LOG_DEBUG(logger, fmt, ...) \
    log_message(logger, LOG_LEVEL_DEBUG, __FUNCTION__, __LINE__, fmt, ##__VA_ARGS__)

#define LOG_INFO(logger, fmt, ...) \
    log_message(logger, LOG_LEVEL_INFO, __FUNCTION__, __LINE__, fmt, ##__VA_ARGS__)

#define LOG_WARNING(logger, fmt, ...) \
    log_message(logger, LOG_LEVEL_WARNING, __FUNCTION__, __LINE__, fmt, ##__VA_ARGS__)

#define LOG_ERROR(logger, fmt, ...) \
    log_message(logger, LOG_LEVEL_ERROR, __FUNCTION__, __LINE__, fmt, ##__VA_ARGS__)

#define LOG_CRITICAL(logger, fmt, ...) \
    log_message(logger, LOG_LEVEL_CRITICAL, __FUNCTION__, __LINE__, fmt, ##__VA_ARGS__)

#endif // LOG_H
