// declarations.h
#ifndef DECLARATIONS_H
#define DECLARATIONS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <direct.h>
#include <io.h>
#include <ctype.h>

#ifdef _WIN32
#include <windows.h>
#endif

// �汾
#define LGD_OS_VERSION "LGD-OS 1.1 Pre-1"
#define BUILDS_DIR "builds"

// ��������
#define MAX_CMD_LEN 1024
#define MAX_PATH_LEN 1024
#define MAX_ARGS 32
#define MAX_HISTORY 100
#define MAX_FILENAME 256
#define MAX_CONTENT_LEN 4096
#define MAX_PIPES 10
#define MAX_INPUT_LEN 1024
#define MAX_TOKENS 100
#define MAX_OUTPUT_LEN 8192

// ����log.h
#include "log.h"

// Shell�����Ľṹ��
typedef struct {
    char current_dir[MAX_PATH_LEN];
    char username[50];
    char hostname[50];
    char home_dir[MAX_PATH_LEN];
    int running;
    int history_count;
    char *history[MAX_HISTORY];  // ��ʷ��¼
    Logger *logger;              // ��־��
} ShellContext;

// ����ṹ��
typedef struct {
    char *name;                                   // ������
    int (*func)(ShellContext *, int, char *[], FILE *, FILE *);  // ����ָ��
    char *brief;                                  // ��Ҫ˵��
    char *detail;                                 // ��ϸ˵��
} Command;

// ȫ���������������
extern Command commands[];
extern int command_count;

// Shell��ʼ��������������
ShellContext *shell_init(void);
void shell_cleanup(ShellContext *ctx);
void shell_run(ShellContext *ctx);
void shell_display_prompt(ShellContext *ctx);
int shell_execute_command(ShellContext *ctx, const char *cmd_line, FILE *in, FILE *out);
int shell_execute_pipeline(ShellContext *ctx, const char *pipeline_cmd);

// ����̨��ɫ
void set_console_color(int color);
void reset_console_color(void);
void get_hostname(char *buffer, int size);
void get_username(char *buffer, int size);

// �ļ�ϵͳ��������
int ensure_builds_directory(void);  // ����int����
void create_linux_directory_structure(void);
int create_directory_if_not_exists(const char *path);
int create_directory_if_not_exists_silent(const char *path);
void real_to_virtual_path(const char *real_path, char *virtual_path);
void sync_existing_directories_silent(void);
int handle_unknown_command(ShellContext *ctx, const char *cmd, int argc, char *argv[], FILE *in, FILE *out);

// ·������
void normalize_path(char *path);
void virtual_to_real_path(const char *virtual_path, char *real_path);
int is_directory(const char *path);
int is_file(const char *path);
void remove_quotes(char *str);
int parse_input(char *input, int *argc, char *argv[]);
void display_prompt(ShellContext *ctx);
int execute_command(ShellContext *ctx, const char *input, FILE *in, FILE *out);

// ����ȱ�ٵĺ�������
void get_file_info_string(const char *path, char *info_str, int buffer_size);

// ���������
int cmd_cd(ShellContext *ctx, int argc, char *argv[], FILE *in, FILE *out);
int cmd_ls(ShellContext *ctx, int argc, char *argv[], FILE *in, FILE *out);
int cmd_ll(ShellContext *ctx, int argc, char *argv[], FILE *in, FILE *out);
int cmd_pwd(ShellContext *ctx, int argc, char *argv[], FILE *in, FILE *out);
int cmd_mkdir(ShellContext *ctx, int argc, char *argv[], FILE *in, FILE *out);
int cmd_rmdir(ShellContext *ctx, int argc, char *argv[], FILE *in, FILE *out);
int cmd_cp(ShellContext *ctx, int argc, char *argv[], FILE *in, FILE *out);
int cmd_mv(ShellContext *ctx, int argc, char *argv[], FILE *in, FILE *out);
int cmd_touch(ShellContext *ctx, int argc, char *argv[], FILE *in, FILE *out);
int cmd_rm(ShellContext *ctx, int argc, char *argv[], FILE *in, FILE *out);
int cmd_cat(ShellContext *ctx, int argc, char *argv[], FILE *in, FILE *out);
int cmd_edit(ShellContext *ctx, int argc, char *argv[], FILE *in, FILE *out);
int cmd_info(ShellContext *ctx, int argc, char *argv[], FILE *in, FILE *out);
int cmd_echo(ShellContext *ctx, int argc, char *argv[], FILE *in, FILE *out);
int cmd_grep(ShellContext *ctx, int argc, char *argv[], FILE *in, FILE *out);
int cmd_wc(ShellContext *ctx, int argc, char *argv[], FILE *in, FILE *out);
int cmd_help(ShellContext *ctx, int argc, char *argv[], FILE *in, FILE *out);
int cmd_exit(ShellContext *ctx, int argc, char *argv[], FILE *in, FILE *out);
int cmd_game(ShellContext *ctx, int argc, char *argv[], FILE *in, FILE *out);
int cmd_osinfo(ShellContext *ctx, int argc, char *argv[], FILE *in, FILE *out);
int cmd_more(ShellContext *ctx, int argc, char *argv[], FILE *in, FILE *out);
int cmd_tree(ShellContext *ctx, int argc, char *argv[], FILE *in, FILE *out);
int cmd_find(ShellContext *ctx, int argc, char *argv[], FILE *in, FILE *out);
int cmd_calc(ShellContext *ctx, int argc, char *argv[], FILE *in, FILE *out);
extern int cmd_mahjong(ShellContext *ctx, int argc, char *argv[], FILE *in, FILE *out);

//��˹��Ԫ����������
static int gaussian_elimination(double **matrix, int n, double *solution, FILE *out);
static int parse_linear_system(const char *system_str, double ***matrix_ptr, int *n_ptr, double **constants_ptr, FILE *out);
static int solve_linear_system(const char *system_str, FILE *out);

#endif // DECLARATIONS_H
