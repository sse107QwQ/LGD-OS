// fs_utils.c
#include "declarations.h"
#include <string.h>
#include <io.h>
#include <stdio.h>
#include <stdlib.h>

// ���BUILDS_DIRû�ж��壬������
#ifndef BUILDS_DIR
#define BUILDS_DIR "builds"
#endif

// ȷ��buildsĿ¼����
int ensure_builds_directory(void) {
    if (_access(BUILDS_DIR, 0) == -1) {
        // buildsĿ¼�����ڣ�������
        if (_mkdir(BUILDS_DIR) == -1) {
            perror("����buildsĿ¼ʧ��");
            return -1;  // ���ش������
        }
        printf("�Ѵ���Ŀ¼: %s\n", BUILDS_DIR);
    }
    return 0;  // ���سɹ�
}

// ͬ������Ŀ¼
void sync_existing_directories_silent(void) {
    char search_path[MAX_PATH_LEN];
    struct _finddata_t fileinfo;
    intptr_t handle;

    snprintf(search_path, MAX_PATH_LEN, "%s\\*", BUILDS_DIR);

    handle = _findfirst(search_path, &fileinfo);
    if (handle == -1L) {
        return;
    }

    do {
        if (fileinfo.attrib & _A_SUBDIR) {
            // ����.��..
            if (strcmp(fileinfo.name, ".") == 0 || strcmp(fileinfo.name, "..") == 0) {
                continue;
            }
            // �����������Ŀ¼ͬ���߼�
        }
    } while (_findnext(handle, &fileinfo) == 0);

    _findclose(handle);
}

// ����LinuxĿ¼�ṹ
void create_linux_directory_structure(void) {
    char real_path[MAX_PATH_LEN];

    // ȷ��buildsĿ¼����
    ensure_builds_directory();

    // ������Ŀ¼�µ���Ŀ¼
    const char *directories[] = {
        "bin", "dev", "etc", "home", "lib", "proc",
        "root", "sbin", "tmp", "usr", "var", NULL
    };

    for (int i = 0; directories[i] != NULL; i++) {
        snprintf(real_path, MAX_PATH_LEN, "%s/%s", BUILDS_DIR, directories[i]);
        if (_access(real_path, 0) != 0) {
            _mkdir(real_path);
        }
    }

    // ֻ��homeĿ¼�´���"user"�ļ���
    const char *user_dir = "user";

    snprintf(real_path, MAX_PATH_LEN, "%s/home/%s", BUILDS_DIR, user_dir);
    if (_access(real_path, 0) != 0) {
        _mkdir(real_path);
    }

    // ��userĿ¼�´���һЩ��Ŀ¼
    const char *user_subdirs[] = {"Desktop", "Documents", "Downloads", "Music", "Pictures", "Videos", NULL};
    for (int j = 0; user_subdirs[j] != NULL; j++) {
        char subdir_path[MAX_PATH_LEN];
        snprintf(subdir_path, MAX_PATH_LEN, "%s/%s", real_path, user_subdirs[j]);
        if (_access(subdir_path, 0) != 0) {
            _mkdir(subdir_path);
        }
    }
}
