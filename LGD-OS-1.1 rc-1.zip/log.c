// log.c
#include "log.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdarg.h>
#include "declarations.h"
// ��ȡ��ǰʱ���ַ���
static void get_time_string(char *buffer, int buffer_size) {
    time_t t = time(NULL);
    struct tm *tm = localtime(&t);
    strftime(buffer, buffer_size, "%Y-%m-%d %H:%M:%S", tm);
}

// ��ȡ��־�����ַ���
const char* get_log_level_string(LogLevel level) {
    switch (level) {
        case LOG_LEVEL_DEBUG:   return "DEBUG";
        case LOG_LEVEL_INFO:    return "INFO";
        case LOG_LEVEL_WARNING: return "WARN";
        case LOG_LEVEL_ERROR:   return "ERROR";
        default:                return "UNKNOWN";
    }
}

// ���ַ�����ȡ��־����
int get_log_level_from_string(const char *level_str) {
    if (strcmp(level_str, "debug") == 0) return LOG_LEVEL_DEBUG;
    if (strcmp(level_str, "info") == 0) return LOG_LEVEL_INFO;
    if (strcmp(level_str, "warning") == 0) return LOG_LEVEL_WARNING;
    if (strcmp(level_str, "error") == 0) return LOG_LEVEL_ERROR;
    return LOG_LEVEL_INFO;  // Ĭ��
}

// ������־��
Logger* create_logger(const char *filename, LogLevel level) {
    Logger *logger = (Logger*)malloc(sizeof(Logger));
    if (!logger) {
        return NULL;
    }

    // �����ļ���
    logger->filename = strdup(filename);
    if (!logger->filename) {
        free(logger);
        return NULL;
    }

    logger->file = NULL;
    logger->level = level;
    logger->max_size = 10 * 1024 * 1024;  // 10MB
    logger->rotate_count = 5;  // ����5������

    // ���Դ���־�ļ�
    logger->file = fopen(filename, "a");
    if (!logger->file) {
        // �����ʧ�ܣ�ʹ�ñ�׼���
        logger->file = stdout;
    }

    return logger;
}

// ������־��
void destroy_logger(Logger *logger) {
    if (logger) {
        if (logger->file && logger->file != stdout && logger->file != stderr) {
            fclose(logger->file);
        }
        if (logger->filename) {
            free(logger->filename);
        }
        free(logger);
    }
}

// ������־����
void set_log_level(Logger *logger, LogLevel level) {
    if (logger) {
        logger->level = level;
    }
}

// ��¼��־��Ϣ
void log_message(Logger *logger, LogLevel level, const char *format, ...) {
    if (!logger || level < logger->level) {
        return;  // ��־������
    }

    char time_str[32];
    get_time_string(time_str, sizeof(time_str));

    // ��ʽ����Ϣ
    char buffer[1024];
    va_list args;
    va_start(args, format);
    vsnprintf(buffer, sizeof(buffer), format, args);
    va_end(args);

    // д����־
    if (logger->file) {
        fprintf(logger->file, "[%s] [%s] %s\n",
                time_str,
                get_log_level_string(level),
                buffer);
        fflush(logger->file);
    }
}
